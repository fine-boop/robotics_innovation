from flask import Flask, request, render_template, flash, redirect, session
import sqlite3
import os
import secrets
from datetime import datetime
app = Flask(__name__)
app.secret_key = secrets.token_hex(64)

def init_db():
    # os.system('rm database.db')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("""CREATE TABLE IF NOT EXISTS users(
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   email TEXT UNIQUE,
                   username TEXT UNIQUE,
                   password TEXT
                   )""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS artefacts(
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   name TEXT UNIQUE,
                   user_that_logged TEXT,
                   date_modified TEXT,
                   site_found TEXT,
                   weight REAL,
                   coords REAL,
                   model_file_location TEXT)""")
    
    conn.commit()
    conn.close()


@app.route('/postit', methods = ["POST",])
def postit():
    pass

@app.route('/', methods = ["GET", "POST"])
def home():
    show_form = False
    item_logged = False
    item_exists = False
    log_artefact_pt1_success = False


    if request.method == 'POST' and 'show_form' in request.form:
        show_form = True
    elif request.method == 'POST' and 'artefact_info' in request.form:
        
        item_name = request.form['item_name']
        site_found = request.form['site_found']
        user_that_logged = session['email']
        coords = request.form['latlng']
        date_modified = datetime.now()
        if item_name and site_found and coords:
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()

            try:
                cursor.execute("INSERT INTO artefacts (user_that_logged, date_modified, name, site_found, weight, coords) VALUES(?, ?, ?, ?, ?, ?)", (user_that_logged, date_modified, item_name, site_found, 1, coords))
                log_artefact_pt1_success = 1
                print("data successfully written to db!")
            except sqlite3.IntegrityError:
                item_exists = True
                print("shits hit the fan") 
                return render_template('index.html', item_exists = item_exists,  show_form = show_form, item_logged = item_logged, log_artefact_pt1_success = log_artefact_pt1_success)
            finally:
                print("Closing DB conn...")
                conn.commit()
                conn.close()
                print("DB conn closed successfully")
                
    elif request.method == 'POST' and 'cords' in request.form:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        conn.commit()
        conn.close()


    return render_template('index.html', show_form = show_form, item_logged = item_logged, log_artefact_pt1_success = log_artefact_pt1_success)


@app.route('/signup', methods = ["GET", "POST"])
def signup():
    email_or_uid_in_use = False
    if request.method == "POST":
        email = request.form['email']
        username = request.form['username']
        password = request.form['password']
        try:
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()
            cursor.execute("INSERT INTO users (email, username, password) VALUES (?, ?, ?)", (email, username, password))
            conn.commit()
            return redirect('/login')
        except sqlite3.IntegrityError:
            email_or_uid_in_use = True
            print("Email/Username is already in use.")
            return render_template('signup.html', email_or_uid_in_use = email_or_uid_in_use)
            
            
        finally:
            conn.close()

    return render_template('signup.html')


@app.route('/login', methods=["POST", "GET"])
def login():
    invalid_creds = False
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        if email and password:
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()
            row_exists = cursor.execute("SELECT 1 FROM users WHERE email = ? LIMIT 1", (email,)).fetchone()
            if row_exists:
                row = cursor.execute("SELECT * FROM users WHERE email = ? LIMIT 1", (email,)).fetchone()
                email_on_db = row[1]
                username_on_the_db = row[2]
                password_on_db = row[3]
                if password_on_db == password:
                    session['email'] = email_on_db
                    session['username'] = username_on_the_db
                    return redirect('/')
                    conn.close()
                else:
                    invalid_creds = True
            else:
                invalid_creds = True

        
            
    return render_template('login.html', invalid_creds=invalid_creds)






if __name__ == "__main__":
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)